"""
Prompts the user for a weight on Earth
and a planet (in separate inputs). Then 
prints the equivalent weight on that planet.

Note that the user should type in a planet with 
the first letter as uppercase, and you do not need
to handle the case where a user types in something 
other than one of the planets (that is not Earth). 
"""

def main():
    # Fill this function out!
    
    # planets = ["Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    # percentages = [0.376, 0.889, 0.378, 2.36, 1.08, 0.815, 1.14]

    # PERCENTAGE_WEIGHTS = dict(zip(planets, percentages))

    # weight_on_earth = float(input("Enter a weight on Earth: "))
    # planet = input("Enter a planet: ").capitalize()

    # if planet in PERCENTAGE_WEIGHTS:
    #     weight_on_planet = round(weight_on_earth * PERCENTAGE_WEIGHTS[planet], 2)
    #     print(f"The equivalent weight on {planet}: {weight_on_planet}")

    # Get input from the user
    weight_on_earth = float(input("Enter a weight on Earth: "))
    planet = input("Enter a planet: ").capitalize()
    
    # Calculate weight based on the selected planet
    if planet == "Mercury":
        weight_on_planet = weight_on_earth * 0.376
    elif planet == "Venus":
        weight_on_planet = weight_on_earth * 0.889
    elif planet == "Mars":
        weight_on_planet = weight_on_earth * 0.378
    elif planet == "Jupiter":
        weight_on_planet = weight_on_earth * 2.36
    elif planet == "Saturn":
        weight_on_planet = weight_on_earth * 1.081
    elif planet == "Uranus":
        weight_on_planet = weight_on_earth * 0.815
    elif planet == "Neptune":
        weight_on_planet = weight_on_earth * 1.14
    else:
        weight_on_planet = weight_on_earth
    
    # Round the result to 2 decimal places
    weight_on_planet = round(weight_on_planet, 2)
    
    # Display the result
    print(f"The equivalent weight on {planet}: {weight_on_planet}")

if __name__ == "__main__":
    main()