"""
Prompts the user for a weight on Earth
and prints the equivalent weight on Mars.
"""

def main():
    # Fill this function out!
    "A function to calculate an Earthling's weight on Mars based on their weight on earth"
     
    PERCENTAGE_WEIGHT_ON_MARS = 0.378
    weight_on_erth = float(input("Enter a weight on Earth: "))

    weight_on_mars = round(weight_on_erth * PERCENTAGE_WEIGHT_ON_MARS, 2)
    print(f"The equivalent weight on Mars: {weight_on_mars}")

if __name__ == "__main__":
    main()