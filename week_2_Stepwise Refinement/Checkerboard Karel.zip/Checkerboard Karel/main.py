from karel.stanfordkarel import *

"""
Karel should fill the whole world with beepers.
"""


from karel.stanfordkarel import *

"""
Karel should fill first line (even) and end in column 1, facing north
if there is a level up, move and fill odd line
return to column 1 and face North
if there is a level up, move and fill even line
return to column 1 and face North
repeat these 2 last commands while North is clear
if North is not clear, Karel must return to start position
"""

def main():
    fill_and_return_even_row()
    while front_is_clear():
        move_to_upper_row()
        fill_and_return_odd_row()
        if front_is_clear():
            move_to_upper_row()
            fill_and_return_even_row()
    step_back()
    
def step_back():
# func make Karel return initial position when North is block
    rotate_180_degrees()
    move_to_end()
    turn_left()

def fill_and_return_even_row():
# func define the steps for even lines (impares)
    put_beeper()
    while front_is_clear():
        move()
        if front_is_clear():
            move()
            put_beeper()
    return_to_starting_position()
    turn_left()

def fill_and_return_odd_row():
# func define the steps for odd lines (pares)
    while front_is_clear():
        move()
        put_beeper()
        if front_is_clear():
            move()
    return_to_starting_position()
    turn_left()

def move_to_upper_row():
# this function make Karel to move the line up if its not block
    if front_is_clear():
        move()
        rotate_270_degrees()

def move_to_end():
# this function let Karel move till the end of the line
    while front_is_clear():
        move()

def rotate_180_degrees():
# this function make Karel turn left 2 times
    turn_left()
    turn_left()

def rotate_270_degrees():
# this function make Karel turn left 3 times
    turn_left()
    turn_left()
    turn_left()

def return_to_starting_position():
# this function make Karel move back to the initial column, 
# keeping in consideration that no wall is ahead before move
    for i in range(2):
        while front_is_clear():
            move()
        rotate_180_degrees()

# There is no need to edit code beyond this point
if __name__ == '__main__':
    main()