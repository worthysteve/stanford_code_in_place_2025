from karel.stanfordkarel import *

def main():
    put_beeper()
    while front_is_clear():
        make_diagonal_beeper()

def make_diagonal_beeper():
    turn_left()
    move()
    turn_right()
    move()
    put_beeper()

def turn_right():
    for _ in range(3):
        turn_left()
        
# don't change this code
if __name__ == '__main__':
    main()