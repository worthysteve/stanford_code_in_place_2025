from karel.stanfordkarel import *

"""
This program commands Karel to fill an entire rectangular world with beepers.
Karel starts in the bottom-left corner, facing east, and finishes in the
top-right corner, facing east, with every square in the grid containing a beeper.
"""

def main():
    """
    Fills the entire world with beepers in a row-by-row manner.
    Karel moves across each row, lays beepers, returns to the start of the row,
    and moves up to the next row until it reaches the top.
    In the final row, it moves to the end without returning.
    """
    while front_is_clear():
        if no_beepers_present():
            # Fill current row with beepers
            fill_row()
            # Return to beginning of the row
            back_to_first_position()
            # Move up to the next row
            face_up()
            # Face east again to continue
            turn_right()
        else:
            # Final row reached; move to end and finish
            go_last_row()

def turn_right():
    """
    Turns Karel 90 degrees to the right.
    Karel only knows how to turn left, so this is done by three left turns.
    """
    turn_left()
    turn_left()
    turn_left()

def fill_row():
    """
    Places a beeper in each cell of the current row by moving forward
    and dropping a beeper until the wall is reached.
    """
    put_beeper()
    while front_is_clear():
        move()
        put_beeper()

def turn_around():
    """
    Turns Karel 180 degrees.
    """
    for _ in range(2):
        turn_left()

def back_to_first_position():
    """
    After filling a row, turns Karel around and moves back to the start of the row.
    """
    turn_around()
    while front_is_clear():
        move()

def face_up():
    """
    After reaching the start of a row, Karel turns to face north and
    moves one cell up to the next row if not blocked.
    """
    for _ in range(3):
        turn_left()  # Equivalent to turning right from west to north
    if front_is_clear():
        move()

def go_last_row():
    """
    In the final row (already filled), Karel moves to the end of the row
    and stops at the top-right corner, facing east.
    No beepers are placed here since it has already been filled.
    """
    while front_is_clear():
        move()

# Entry point for the Karel program
if __name__ == '__main__':
    main()
