from karel.stanfordkarel import *

"""
Karel starts in front of a pile of beepers.
She should pick them up one at a time and place each beeper in an empty cell
spaced one square apart, going right.
"""

def main():
    move()  # Move to the pile of beepers
    while beepers_present():
        pick_beeper()                  
        move_to_next_empty()          
        put_beeper()                
        return_to_pile()        

def move_to_next_empty():
    """
    Move forward until finding a square with no beeper.
    This is where the next beeper will be placed.
    """
    while beepers_present():
        move()

def return_to_pile():
    """
    Turn around and move back to the pile to pick another beeper.
    """
    turn_around()
    while front_is_clear() and no_beepers_present():
        move()
    move()
    turn_around()

def turn_around():
    turn_left()
    turn_left()

# There is no need to edit code beyond this point
if __name__ == '__main__':
    main()
