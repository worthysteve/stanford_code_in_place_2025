from karel.stanfordkarel import *

"""
File: main.py
--------------------
When you finish writing this file, Karel should have repaired 
each of the columns in the temple
"""
def main():
    """
    Karel builds columns under the arches in the Temple of Artemis.
    Karel starts at the bottom left corner and places beepers to complete
    the missing columns under each arch.
    """
    # Karel starts at bottom left corner
    # Move Karel to each column position and build columns
    build_all_columns()

def build_all_columns():
    """
    Build all columns in the temple.
    Karel starts at the bottom left corner facing east.
    """
    # First column is at the starting position
    build_single_column()
    
    # Move to each subsequent column position and build
    for _ in range(3):  # There are 4 columns total based on the images
        move_to_next_column()
        build_single_column()

def build_single_column():
    """
    Builds a single column at Karel's current position.
    Assumes Karel is at the bottom of the column facing east.
    """
    # Turn to face north (up the column)
    turn_left()
    
    # Go up the column and place beepers where needed
    while front_is_clear():
        if no_beepers_present():
            put_beeper()
        move()
    
    # Check the top position
    if no_beepers_present():
        put_beeper()
    
    # Return to the bottom
    turn_around()
    while front_is_clear():
        move()
    
    # Turn back to face east
    turn_left()

def move_to_next_column():
    """
    Moves Karel from one column position to the next.
    Assumes Karel is facing east.
    """
    for _ in range(4):
        move()

def turn_around():
    """
    Makes Karel turn around (180 degrees).
    """
    turn_left()
    turn_left()

if __name__ == '__main__':
    main()
