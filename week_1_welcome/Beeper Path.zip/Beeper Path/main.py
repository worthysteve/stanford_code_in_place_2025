from karel.stanfordkarel import *

def main():
    # check if beepers are on the way! if they are, keep moving.
    while beepers_present():
        move()


# There is no need to edit code beyond this point

if __name__ == '__main__':
    main()