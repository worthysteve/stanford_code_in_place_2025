from karel.stanfordkarel import *

"""
When you finish writing this file, Karel should be able to 
place 20 beepers, then 25 beepers, and end facing East to 
the right of the 25 beepers.
"""

def main():
    """
    A function to put 20 beepers in Karel's current position 
    and then move one step and put 25 beepers in its current 
    position and move one step eastward.
    """
    put_20_beepers()
    move()
    put_25_beepers()
    move()

# function to put 20 beepers in a place
def put_20_beepers():
    for i in range(20):
        put_beeper()

# function to put 25 beepers in a place
def put_25_beepers():
    for i in range(25):
        put_beeper()


if __name__ == '__main__':
    main()