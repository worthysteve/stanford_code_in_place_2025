from karel.stanfordkarel import *

def main():
    put_10_beepers()
    while front_is_clear():
        move()
        put_10_beepers()
        

def put_10_beepers():
    for i in range(10):
        put_beeper()


if __name__ == '__main__':
    main()
