from karel.stanfordkarel import *

# Here is a place to program your Section problem

def main():
    """
    Karel walks along a row, building a 2x3 hospital at each beeper location.
    Each hospital has its corner at the location of the supply pile.
    """
    while front_is_clear():
        move()
        if beepers_present():
            build_hospital()

def build_hospital():
    """
    Builds a 2x3 hospital (2 columns, 3 rows) with the bottom-left corner
    at Karel's current position.
    """
    # We're already on the first beeper position
    # Now build the 2x3 grid of beepers
    turn_left()
    move()
    put_beeper()  # Middle left
    move()
    put_beeper()  # Top left
    turn_right()
    move()
    turn_right()
    
    # Second column (going down)
    put_beeper()  # Top right
    move()
    put_beeper()  # Middle right
    move()
    put_beeper()  # Bottom right
    
    # Return to bottom row, facing right
    turn_left()

def turn_right():
    """
    Makes Karel turn right by turning left three times.
    """
    for i in range(3):
        turn_left()

if __name__ == '__main__':
    main()