from karel.stanfordkarel import *

# File: shelter.py
# -----------------------------
# The warmup program defines a "main"
# function which should make Karel 
# move to the beeper, pick it up, and
# return home.
def main():
    move()
    # add your code here
    move()
    face_down()
    move()
    turn_left()
    move()
    pick_beeper()
    turn_around()
    for i in range(3):
        move()
    face_down()
    move()
    face_down()
    
def face_down():
    for i in range(3):
        turn_left()  

def turn_around():
    for i in range(2):
        turn_left()  
# don't edit these next two lines
# they tell python to run your main function
if __name__ == '__main__':
    main()