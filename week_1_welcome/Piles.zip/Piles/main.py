from karel.stanfordkarel import *

# File: piles.py
# -----------------------------
# The warmup program defines a "main"
# function which should make Karel
# pick up all the beepers in the world.
def main():
    """This function makes karel move a step, pick 10 beepers,
    move 2 steps forward and pick 10 beepers again and repeat 
    the same step and move one step forwaed"""
    move()
    # your code here
    for i in range(2):
        pick_10_beepers()
        move()
        move()
    pick_10_beepers()
    move()



def pick_10_beepers():
    """This function makes karel pick up ten beepers in one position"""
    for i in range(10):
        pick_beeper()  
   
   
# don't edit these next two lines
# they tell python to run your main function
if __name__ == '__main__':
    main()